﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringTab
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] MatSize = new int[2];
            string[,] TextTable = GenerateTable(MatSize);
            Console.WriteLine("The End");
            Console.ReadKey();
        }

        static void GetSize(ref int[] zwrotka)
        {
            String Input;
            //int NumbersNo = 0;
            bool qualitycheck = false;

            Console.WriteLine("Podaj ile wierszy ma mieć tablica\n");
            while (qualitycheck == false)
            {
                try
                {
                    Input = Console.ReadLine();
                    zwrotka[0] = int.Parse(Input);
                    qualitycheck = true;
                }
                catch
                {
                    Console.WriteLine("To nie jest poprawna liczba. Wpisz lepszą.");
                }
            }

            qualitycheck = false;

            Console.WriteLine("Podaj ile kolumn ma mieć tablica\n");
            while (qualitycheck == false)
            {
                try
                {
                    Input = Console.ReadLine();
                    zwrotka[1] = int.Parse(Input);
                    qualitycheck = true;
                }
                catch
                {
                    Console.WriteLine("To nie jest poprawna liczba. Wpisz lepszą.");
                }
            }
        }

        static string[,] GenerateTable (int[] zwrotka)
        {
            string[,] WorkTable = new string[zwrotka[0],zwrotka[1]];

            for (int i = 0; i < zwrotka[0]; i++)
            {
                for (int j = 0; j < zwrotka[2]; j++)
                {
                    Console.WriteLine("\nPodaj tekst w komórce " + (i+1).ToString() +"'" + (j+1).ToString() + " \n");
                    WorkTable[i,j] = Console.ReadLine();
                }
            }

            return WorkTable;

        }

        static void ReverseTable(ref string[,] WorkTable)
        {
            foreach(string item in WorkTable)
            {
                item = Array.Reverse(item.ToCharArray());
            }
        }


    }

    
}
