﻿using System;
using System.Collections;
using System.Linq;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            NicNieZwracamINiePrzyjmuje();

            NicNieZwracamAlePrzyjmuje(Console.ReadLine());

            NicNieZwracamAlePrzyjmuje(b: 10);
            Console.WriteLine();

            ArrayList newArray = new ArrayList();
            int RozmiarAL = newArray.Count;

            newArray.Add(15);
            newArray.Add("test");
            newArray.Add(DateTime.Now.AddYears(-24));

            foreach (var item in newArray)
            {
                if (item is int)
                {
                    Console.WriteLine("\nLiczba " + item);
                }
            }

            int a = 5;
            Metoda(ref a);
            Console.WriteLine(a);

            M2(17, 789, -437, 98, 80);



            Console.WriteLine("\n\nKoniec");
            Console.ReadKey();
        }

        static void NicNieZwracamINiePrzyjmuje()
        {
            Console.WriteLine("Nic nie oddam!");
        }

        static void NicNieZwracamAlePrzyjmuje(int abc)
        {
            Console.WriteLine("Przyjąłem liczbę: " + abc);
        }


        // funkcja przeciążone - umozliwia wywołanie jedną nazwą różnych funkcji zależnie od nadanych parametrów
        static void NicNieZwracamAlePrzyjmuje(string abc)
        {
            Console.WriteLine("Przyjąłem tekst: " + abc);
        }

        static void NicNieZwracamAlePrzyjmuje(int a = 10, int b = 57, int c = 16)
        {
            Console.WriteLine("\nSuma liczb : " + (a+b+c).ToString());
        }

        static int Dodaj(string a, string b)
        {
            int x, y;
            if (int.TryParse(a,out x))
            {
                if (int.TryParse(b, out y))
                {
                    return x + y;
                }
            }
            return 0;
        }

        static void M2(params int[] liczba)
        {
            Console.WriteLine(liczba.Count() + "\n");
        }
        
        static void Metoda(ref int a)
        {
            a = 10;
        }
        
    }
}
