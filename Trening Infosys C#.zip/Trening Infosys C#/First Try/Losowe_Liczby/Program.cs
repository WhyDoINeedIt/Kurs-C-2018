﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Losowe_Liczby
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList MyArray = new ArrayList();
            int ItemsCount = GetSize();
            FillArray(ref MyArray, ItemsCount);
            PrintArray(MyArray);

            Console.WriteLine("\n\nEnd");
            Console.ReadKey();
            
        }

        static int GetSize()
        {
            String Input;
            int NumbersNo = 0;
            bool qualitycheck = false;

            Console.WriteLine("Podaj ile liczb chcesz wpisać\n");
            while (qualitycheck == false)
            {
                try
                {
                    Input = Console.ReadLine();
                    NumbersNo = int.Parse(Input);
                    qualitycheck = true;
                }
                catch
                {
                    Console.WriteLine("To nie jest poprawna liczba. Wpisz lepszą");
                }
            }
            return NumbersNo;
        }

        static void FillArray(ref ArrayList WorkArray, int Counter)
        {
            Random RNG = new Random();
            for (int i=0; i<Counter; i++)
            {
                WorkArray.Add(RNG.Next(1,100));
            }

        }

        static void PrintArray(ArrayList WorkArray)
        {
            int Counter = WorkArray.Count;
            for (int i=0;i<Counter;i++)
            {
                if (int.Parse(WorkArray[i].ToString()) % 2 == 0)
                {
                    Console.WriteLine(WorkArray[i].ToString() + "\n");
                }
            }
        }
    }
}
