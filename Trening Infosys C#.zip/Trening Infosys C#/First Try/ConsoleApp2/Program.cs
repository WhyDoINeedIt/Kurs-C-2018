﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            int b = 100;

            int Counter = a;
            while (Counter <=b)
            {
                if (Counter % 33 == 0)
                {
                    Console.WriteLine("Liczba " + Counter + " dzieli się przez 33\n");
                }
                Counter++;
            }

            for (int i = 0; i <= 1000; i++)
            {
                if (i % 123 == 0)
                {
                    Console.WriteLine("Liczba " + i + " dzieli się przez 123\n");
                }
            }

            for (; Counter <= 1000; Counter++)
            {
                if (Counter % 72 == 0)
                {
                    Console.WriteLine("Liczba " + Counter + " dzieli się przez 72\n");
                }
            }

            string BaseText = "Let's test this";
            Char[] Tablica = BaseText.ToCharArray();

            foreach (char item in Tablica)
            {
                Console.WriteLine(item.ToString());
            }

            Console.WriteLine("\nKoniec");
            Console.ReadKey();
        }
    }
}
