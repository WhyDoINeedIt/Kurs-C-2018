﻿// komentarz jedna linia

using System; // refka do komend systemowych

/*
 Komentarz na kilka linijek

 ctrl + . - podpowiedź
 
 */

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            // uruchamiana automatycznie przez program

            String strTekstDoWyswietlenia;
            String strWynik;
            String strDisplayComment;
            String strAddress;
            Char chrPojedynczyZnak;
            Char[] chrarrWektorZnakow;

            int i = 2543;
            int intKtoryZnak;

            DateTime Data;

            //Console.WriteLine("Musisz nacisnąć przycisk");
            //Console.WriteLine("");
            //Console.ReadKey();
            Console.WriteLine("");
            Console.WriteLine("Wprowadź tekst + ENTER");
            Console.WriteLine("");
            strTekstDoWyswietlenia = Console.ReadLine(); // potwierdzony enterem
            Console.WriteLine("Wpisałeś tekst: \n" + strTekstDoWyswietlenia);
            strDisplayComment = "Wpisałeś tekst:";
            strWynik = $"{strDisplayComment} {strTekstDoWyswietlenia}";
            Console.WriteLine(strWynik +"\n");
            strAddress = @"C:\Windows";
            intKtoryZnak = 3;
            chrPojedynczyZnak = strAddress.ToCharArray()[intKtoryZnak];
            Console.WriteLine("Pełny adres: " + strAddress + "\n");
            Console.WriteLine("Znak numer " + intKtoryZnak.ToString() + " to: " + chrPojedynczyZnak + "\n");
            chrarrWektorZnakow = strTekstDoWyswietlenia.ToCharArray();

            Console.WriteLine(i.ToString() + "\n");

            Data = DateTime.Now;

            Console.WriteLine("Obecny czas: " + Data.ToString("hh:mm").ToString() + "\n");

            i++;

            i -= 123;

            i = i % 3; // reszta z dzielenia

            /* Warunki:
             *  && - and
             *  || - or
             */  

            Console.WriteLine(i.ToString() + "\n");

            Console.WriteLine("\n\nKoniec");
            Console.ReadLine();

            
        }

        static bool GetDate()
        {
            DateTime DateToSend;
            String DataUrodzenia;
            DataUrodzenia = Console.ReadLine();
            DateToSend = DateTime.ParseExact(DataUrodzenia, @"dd//mm//yyyy", System.Globalization.CultureInfo.InvariantCulture);
            GetWiek(DateToSend);

            return true;

        }

        static int GetWiek(DateTime DataUrodzenia)
        {
            int Wynik = 0;
            DateTime Calculated = DateTime.Now - DataUrodzenia;
            Wynik = Calculated.Year;
            return Wynik;
        }
    }
}
