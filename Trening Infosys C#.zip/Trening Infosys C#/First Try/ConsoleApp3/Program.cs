﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            String Input;
            int NumbersNo=0;
            bool qualitycheck = false;
            int Counter = 0;
            bool EvenCheck = false;

            Console.WriteLine("Podaj ile liczb chcesz wpisać\n");
            while (qualitycheck == false)
            {
                try
                {
                    Input = Console.ReadLine();
                    NumbersNo = int.Parse(Input);
                    qualitycheck = true;
                }
                catch
                {
                    Console.WriteLine("To nie jest poprawna liczba. Wpisz lepszą");
                }
            }


            int[] Tablica = new int[NumbersNo];

            for (int i = 0; i < NumbersNo; i++)
            {
                Console.WriteLine("Podaj ile liczb numer " + (i+1).ToString() + " \n");
                qualitycheck = false;
                while (qualitycheck == false)
                {
                    try
                    {
                        Input = Console.ReadLine();
                        Tablica[i] = int.Parse(Input);
                        qualitycheck = true;
                    }
                    catch
                    {
                        Console.WriteLine("To nie jest poprawna liczba. Wpisz lepszą");
                    }
                }
            }

            Console.WriteLine("\n\n");

            while (Counter < NumbersNo)
            {
                if (Tablica[Counter]%2==0)
                {
                    Console.WriteLine(Tablica[Counter].ToString() + " jest liczbą parzystą\n");
                    EvenCheck = true;
                }
                Counter++;
            }

            if (EvenCheck == false)
            {
                Console.WriteLine("Nie podałeś żadnych liczb parzystych\n");
            }

            Console.WriteLine("\n\nKoniec");
            Console.ReadKey();
        }
    }
}
