﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //List<int> kolekcja = new List<int>();
            //kolekcja.Add(2);
            //kolekcja.Add(12);
            //kolekcja.Add(3);
            //kolekcja.Add(12);
            //int i = kolekcja[3];
            //kolekcja.RemoveAt(3);
            ////sortowanie

            //kolekcja.Remove(12);
            //ArrayList arrayList = new ArrayList();

            Person p1 = new Person();
            Person p2 = new Person(300);
            Person p3 = new Person(300,"Dominik");
            Person p4 = new Person { Imie = "Dominik", Wiek = 300 };

            int a = 10;
            int b = a;
            b = 22;
            Console.WriteLine(a); //jaka wartosc? 10

            //referencyjny
            Person pp1 = new Person { Imie = "Janusz" };
            Person pp2 = new Person();
            pp2 = pp1; 
            pp2.Imie = "Dominik";
            Console.WriteLine(pp1.Imie); //jaka wartosc? Dominik


            



            StringBuilder strB = new StringBuilder();
            strB.Append("Ala ");
            strB.Append("ma ");
            strB.Append("kota");
            string ala = strB.ToString();

            //int i = person.GetZmienna();
            //person.SetZmienna(33);
            //int w = person.Wiek; //otrzymac 300

            Console.WriteLine("Koniec");
            Console.ReadKey();
        }
    }
}
