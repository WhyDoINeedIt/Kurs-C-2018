﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    //public 
    //internal 
    //protected <-- private tylko ze widoczny dla kasy potomnej
    //private
    class Person
    {
        //ctor
        public Person()
        {

        }

        public Person(int wiek)
        {
            this.Wiek = wiek;
        }

        public Person(int wiek, string imie)
        {
            this.Wiek = wiek;
            this.Imie = imie;
        }

        private string _imie;
        private int _zmienna;
        private int _wiek;

        public int PublicznaZmienna;

        public string Imie
        {
            get {
                StatycznaKlasa.Zmienna = 100;
                return _imie; }
            set { _imie = value; }
        }

        public int Wiek
        {
            get { return _wiek; }
            set
            {
                if (value > 0 && value < 100)
                    _wiek = value;
            }
        }

        public int GetZmienna()
        {
            return _zmienna;
        }

        public void SetZmienna(int i)
        {
            if (i > 0 && i < 100)
                _zmienna = i;
        }

        //public int Zmienna;

        //Zadanie: akcesor Get Set

        //zmienna/pole

        //public int ZmiennaPubliczna;


        ////wlasciwosc z akcesorami get i set
        //public int Zmienna { get; set; }

        //prop + 2xtab
        //public int Wiek { get; set; }







    }
}
