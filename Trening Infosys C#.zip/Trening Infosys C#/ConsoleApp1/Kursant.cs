﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Kursant: Person //mozna dziedziczyc tylko po 1 klasie
    {
        public Kursant()
        {
            
        }
    }

    static class StatycznaKlasa
    {
        public static int Zmienna;
        public static void Metoda()
        {

        }
    }
}
