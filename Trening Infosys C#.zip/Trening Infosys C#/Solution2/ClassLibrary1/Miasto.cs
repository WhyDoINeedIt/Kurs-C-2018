﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Model
{
    public class Miasto: AbstractClass
    {
        //walidacja przez data annotations (dodane z referencji) - działa tylko dla properties, nie dla zwykłych zmiennych
        [StringLength(50)] [Required] public string Nazwa { get; set; }
        [Range (1,100)] public List<Mieszkancy> ListaMieszkancow { get; set; }
    }
}
