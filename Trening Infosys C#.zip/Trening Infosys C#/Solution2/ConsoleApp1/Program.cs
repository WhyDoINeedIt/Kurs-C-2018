﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            RealClass test = new RealClass();
            test.zmienna = 36;
            test.MetodaZwykla();
            test.MetodaAbstract();
            Console.ReadKey();
        }

        abstract class AbsClass
        {
            public int zmienna;
            public void MetodaZwykla()
            {
                Console.WriteLine("To jest zwykła metoda\n\nZmienna wynosi " + zmienna + "\n");
            }

            public abstract void MetodaAbstract(); 
        }

        class RealClass : AbsClass
        {
            public override void MetodaAbstract()
            {
                Console.WriteLine("To jest zaimplementowana metoda abstract");
            }
        }

        abstract class AbsClassv2: AbsClass
        {

        }

        class RealClass2 : AbsClassv2
        {
            public override void MetodaAbstract()
            {
                Console.WriteLine("To jest zaimplementowana metoda abstract");
            }
        }
    }
}
