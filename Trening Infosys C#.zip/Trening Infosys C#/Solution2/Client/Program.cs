﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using Model;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            KursDBContext db = new KursDBContext();

            AddCity(db);
        }


        //CREATE
        static void AddCity(KursDBContext baza) // zalinkować db
        {

            Miasto miasto = new Miasto();
            miasto.Nazwa = "Gdańsk";
            miasto.ID = 2;

            baza.Miasto.Add(miasto);
            baza.SaveChanges();
        }

        //DELETE
        public void DeleteCity(KursDBContext db)
        {
            Miasto drugi = (from cokolwiek in db.Miasto
                            where cokolwiek.ID == 1
                            select cokolwiek).Single();

            Console.WriteLine(drugi.ID);
            Console.ReadKey();

            db.Miasto.Remove(drugi);
            db.SaveChanges();
        }
    }
}
