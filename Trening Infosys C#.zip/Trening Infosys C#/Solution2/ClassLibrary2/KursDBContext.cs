﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity; //załadowany z ManageNuGet
using Model;

namespace DAL
{
    public class KursDBContext: DbContext
    {
        public KursDBContext(): base("MojeDb")
        {

        }
        public DbSet<Miasto> Miasto { get; set; }
        public DbSet<Mieszkancy> Osoba { get; set; }
    }
}
