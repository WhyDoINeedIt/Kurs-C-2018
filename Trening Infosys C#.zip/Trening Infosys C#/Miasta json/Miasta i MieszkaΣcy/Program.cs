﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Miasta_i_Mieszkańcy
{
    class Program
    {
        

        static void Main(string[] args)
        {
            string[] NazwyMiast = { "Łódź", "Warszawa", "Kraków", "Kielce", "Poznań", "Gdańsk" };
        }

        static List<Miasto> GenerateCities(string[] NazwyMiast)
        {

            foreach (string str in NazwyMiast)
            {

            }
        }
    }
}
