﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Miasta_i_Mieszkańcy
{
    class Mieszkancy
    {
        public int MieszkancyID { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public int Miejscowość { get; set; }

        public Mieszkancy(string Imie, string Nazwisko)
        {
            this.MieszkancyID = Mieszkancy_BackEnd.GetID();
            this.Imie = Imie;
            this.Nazwisko = Nazwisko;

        }

        private int GetMiasto(List<Miasto> Miasta, string SzukanaNazwa)
        {
            int MiastaCount = Miasta.Count();
            int Current = 0;
            while(Current < MiastaCount)
            {
                if (Miasta[Current].Nazwa == SzukanaNazwa)
                {
                    Current = MiastaCount;
                    return Miasta[Current].MiastoID;
                }
                Current++;
            }
            return 0;
        }

    }

    class Mieszkancy_BackEnd
    {
        private static int _nextID = 0;

        public static int GetID()
        {
            return ++_nextID;
        }
    }

    class Miasto
    {
        public int MiastoID;
        public string Nazwa;
    }
    
}
