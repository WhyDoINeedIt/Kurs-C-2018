﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApp5
{
    class Person : IPerson
    {
        public string Imie { get; set; }

        public string GetImie()
        {
            return this.Imie;
        }

        private string _nazwisko;

        public String Nazwisko
        {
            get
            {
                return this._nazwisko;
            }
            set
            {
                this._nazwisko = value;
            }
        }
    }
}
