﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaneOsobowe
{
    public class Osoba
    {
        public long ID { get; set; }
        public String Imie { get; set; }
        public String Nazwisko { get; set; }
        public DateTime DataUrodzenia { get; set; }
        
        private void SetID()
        {
            this.ID = BackEnd.GenerateID();
        }

        public Osoba(String inputImie, String inputNazwisko, DateTime inputUrodzony)
        {
            this.Imie = inputImie;
            this.Nazwisko = inputNazwisko;
            this.DataUrodzenia = inputUrodzony;
            this.SetID();
        }

    }

    static public class BackEnd
    {
        private static long nextID = 0;

        public static long GenerateID()
        {
            nextID++;
            return nextID;
        }
    }
}
