﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DaneOsobowe; // referencja do ClassLibrary1 - project -> right click -> Add -> reference - wybrać bibliotekę


namespace Cwiczenie
{
    class Program
    {
        static void Main(string[] args)
        {
            
            List<Osoba> Lista = GenerateList();
            //Osoba test = new Osoba("Robert","NieWiem",DateTime.Now.AddYears(-20));
            Osoba ToPrint = GetUserByID(Lista);
            if (ToPrint!= null)
            {
                Console.WriteLine(ToPrint.Imie + " " + ToPrint.Nazwisko + " " + GetAge(ToPrint));
            }
            else
            {
                Console.WriteLine("Nie znaleziono ID");
            }
            List<Osoba> Pelnoletni = PickAge(Lista);
            PrintFullList(Pelnoletni);

            Console.ReadKey();
        }

        static Osoba GetUserByID(List<Osoba> Lista)
        {
            bool qualitycheck = false;
            int SearchID =-1;
            Console.WriteLine("\nPodaj szukane ID");
            while (qualitycheck == false)
            {
                try
                {
                    SearchID = int.Parse(Console.ReadLine());
                    qualitycheck = true;
                }
                catch
                {
                    Console.WriteLine("\nID musi być liczbą");
                }
            }
            int ListCount = Lista.Count();
            for (int i=0; i<ListCount;i++)
            {
                if (Lista[i].ID == SearchID)
                {
                    return Lista[i];
                }
            }
            return null;
        }

        static List<Osoba> GenerateList()
        {
            Random RNG = new Random();
            int[] ForGeneration = new int[3];
            int MaxPeople = 20;
            List<Osoba> ListaOsobowa = new List<Osoba>();
            String[] NamesArray = { "Robert", "Anna", "Gosia", "Staszek", "Emil", "Kamil" };
            String[] FamilyArray = { "Kowalski", "Nowak", "Młynarczyk", "Radoń" };
            for (int i =0; i<MaxPeople; i++)
            {
                ForGeneration[0] = RNG.Next(0, 5);
                ForGeneration[1] = RNG.Next(0, 3);
                ForGeneration[2] = RNG.Next(1, 80);
                ListaOsobowa.Add(new Osoba(NamesArray[ForGeneration[0]], FamilyArray[ForGeneration[1]], DateTime.Now.AddYears(-ForGeneration[2])));
            }
            return ListaOsobowa;
        }

        static int GetAge(Osoba DoWieku)
        {
            return DateTime.Now.Year - DoWieku.DataUrodzenia.Year;
        }

        static List<Osoba> PickAge(List<Osoba> FullList)
        {
            for (int i=0;i< FullList.Count(); i++)
            {
                if (GetAge(FullList[i])<18)
                {
                    FullList.Remove(FullList[i]);
                    i--;
                }
            }
            return FullList;
        }

        static void PrintFullList(List<Osoba> ToPrint)
        {
            int ListCount = ToPrint.Count();
            Console.WriteLine("\n");
            for (int i = 0; i < ListCount; i++)
            {
                Console.WriteLine(ToPrint[i].Imie + " " + ToPrint[i].Nazwisko + " " + GetAge(ToPrint[i]));
            }

        }
    }

    class Testowa
    {
        public override string ToString()
        {
            return base.ToString(); //można nadpisać swoim kodem
        }
    }

    class MojaKolekcja: List<Osoba>
    {
        public override string ToString()
        {
            StringBuilder str = new StringBuilder();
            foreach (var item in this)
            {
                str.Append(item.Imie);
                str.Append(" ");
                str.Append(item.Nazwisko);
                str.Append("\n");
            }
            return str.ToString();
        }
    }
}
