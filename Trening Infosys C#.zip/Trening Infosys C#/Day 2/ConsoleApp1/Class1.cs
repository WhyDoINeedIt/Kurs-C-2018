﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    //public
    //internal
    //protected
    //private
    class Person
    {
        public int ZmiennaPublic;
        internal int ZmiennaInternal;
        protected int _zmiennaProtected;
        private int _zmiennaPrivate;
    }
}
