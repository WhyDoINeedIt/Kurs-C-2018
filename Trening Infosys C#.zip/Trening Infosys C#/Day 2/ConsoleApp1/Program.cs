﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> kolekcja = new List<int>();
            kolekcja.Add(2);
            kolekcja.Add(12);
            kolekcja.Add(45);
            kolekcja.Add(12);
            kolekcja.Remove(12); // usunie pierwszą dwunastkę

            List<int> kolekcja2 = GenerateList();
            SortList(ref kolekcja2);
            PrintList(kolekcja2);


            Console.ReadKey();

        }

        static List<int> GenerateList()
        {
            List<int> Wyniki = new List<int>();
            Random RNG = new Random();
            int rozmiarkolekcji = RNG.Next(5, 20);
            for (int count = 0; count<rozmiarkolekcji; count++)
            {
                Wyniki.Add(RNG.Next(1, 897));
            }
            return Wyniki;
        }

        static void SortList(ref List<int> WorkList)
        {
            int ListSize = WorkList.Count();
            int counter1 = 0, counter2 = 1, storeroom = 0;
            while(counter1<ListSize)
            {
                counter2 = counter1 + 1;
                while(counter2<ListSize)
                {
                    if (WorkList[counter2]<WorkList[counter1])
                    {
                        storeroom = WorkList[counter1];
                        WorkList[counter1] = WorkList[counter2];
                        WorkList[counter2] = storeroom;
                    }
                    counter2++;
                }
                counter1++;
            }
        }

        static void PrintList(List<int> WorkList)
        {
            int ListSize = WorkList.Count();
            int counter1 = 0;
            for(;counter1<ListSize;counter1++)
            {
                Console.WriteLine(WorkList[counter1].ToString() + "\n");
            }
        }

    }
}
