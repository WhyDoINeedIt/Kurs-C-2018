﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CModels
{
    public class Kursant
    {
        public int ID { get; set; }
        public string Imie { get; set; }

        public Kursant(string Name)
        {
            this.Imie = Name;
            this.ID=BackEnd.generateNewID();
        }

    }

    static public class BackEnd
    {
        static private int nextID = 0;

        static public int generateNewID()
        {
            return ++nextID;
        }
    }
}
