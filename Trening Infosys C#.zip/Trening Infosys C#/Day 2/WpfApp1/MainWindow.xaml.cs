﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CModels; //dodaje refkę do customowej biblioteki;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static List<Kursant> ListaKursantow;

        public MainWindow()
        {
            InitializeComponent();
            ListaKursantow = new List<Kursant>();
            lvMyList.ItemsSource = ListaKursantow;
        }

        private void btnButton_Click(object sender, RoutedEventArgs e)
        {
            string Imie = txtImie.Text;
            ListaKursantow.Add(new Kursant(Imie));
            txtLabel.Content = "Dodałeś " + Imie + " - nadano ID: " + ListaKursantow[ListaKursantow.Count -1].ID.ToString();
            //UpdateListView();
        }
        
        /*private void UpdateListView()
        {
            foreach (Kursant item in ListaKursantow)
            {
                lvMyList.Items.Add(item.Imie);
            }
        }*/
    }
}
