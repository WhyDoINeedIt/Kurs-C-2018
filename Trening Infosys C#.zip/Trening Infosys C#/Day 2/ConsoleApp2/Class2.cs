﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Kursant: Person //dziedziczy elementy z Person.
    {
        public Kursant()
        {
            
        }
    }

    static class StaticClass
    {
        public static int zmienna;
    }
}
