﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    //public
    //internal
    //protected
    //private
    class Person
    {
        //variables
        public int ZmiennaPublic;
        internal int ZmiennaInternal;
        protected int _zmiennaProtected;
        private int _zmiennaPrivate;

        public Person()
        {

        }

        public Person(int Wiek)
        {
            this._wiek = Wiek;
        }

        public Person(int Wiek, string Imie)
        {
            this._wiek = Wiek;
            this._imie = Imie;
        }

        //property
        public int Zmienna { get; set; }

        //public int Wiek { get; set; }

        private int _wiek;
        private string _imie;

        public int Wiek
        {
            get { return _wiek; }
            set
            {
                if (value >= 0 && value <= 120)
                {
                    _wiek = value;
                }
            }
        }

        public string Imie
        {
            get { return _imie; }
            set
            {
                    _imie = value;
            }
        }


        //function
        public void SetZmienna(int Value)
        {
            _zmiennaPrivate = Value;
        }

        public int GetZmienna()
        {
            return _zmiennaPrivate;
        }
    }
}
