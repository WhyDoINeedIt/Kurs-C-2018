﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        // string + string tworrzy nowe komórki pamięci
        // StringBuilder działa lepiej niż string + string dla 6 i więcej elementów

        // klasy domyślnie przekazują się jako referencje

        // statyczne klasy są współdzielone na cały projekt

        static void Main(string[] args)
        {
            Person zmienna = new Person();
            zmienna.SetZmienna(127);
            Console.WriteLine(zmienna.GetZmienna());
            Person Osoba = new Person(27, "Adam");
            Console.WriteLine("\n" + Osoba.Imie);
            Console.WriteLine(Osoba.Wiek);

            Osoba.Wiek = 28;

            Console.WriteLine("\n" + Osoba.Imie);
            Console.WriteLine(Osoba.Wiek);

            Console.ReadKey();

        }
    }
}
