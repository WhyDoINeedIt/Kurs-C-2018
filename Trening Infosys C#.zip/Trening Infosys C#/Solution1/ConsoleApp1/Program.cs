﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string plik = "text.txt";
            if(!File.Exists(plik))
            {
                File.Create(plik);
            }

            StreamWriter sw = new StreamWriter(plik);

            Person person = new Person {
                ID = 1,
                Name = "Tomasz"
            };

            //string content = JsonConvert.SerializeObject(person);

            string path = @"c:\\";
            string[] foldery = Directory.GetDirectories(path);
            foreach (string str in foldery)
            {
                sw.WriteLine(str);
            }


            sw.Close();
            sw.Dispose();

            Console.WriteLine("Koniec");
            Console.ReadKey();
        }

        public class Person
        {
            public int ID;
            public string Name;
        }
    }
}
